def receive():
    return 'I am receive'
